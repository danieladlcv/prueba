/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clasesproyecto;

import java.util.List;

/**
 *
 * @author Michael
 */
public class Encuesta {
    private int id; 
    private String titulo;              // Título de la encuesta
    private String descripcion;         // Descripción de la encuesta
    private List<String> preguntas;     // Lista de preguntas de la encuesta
    private List<String> respuestas;    // Lista de respuestas recopiladas       
    private boolean activa; 

    public Encuesta(int id, String titulo, String descripcion, List<String> preguntas, List<String> respuestas, boolean activa) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.preguntas = preguntas;
        this.respuestas = respuestas;
        this.activa = activa;
    }

    
   
    
    
    
    
    
    
}
