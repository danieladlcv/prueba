/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Clasesproyecto;

/**
 *
 * @author Michael
 */

import Interfacesmodelo.Usu; 
import Base.DatabaseConnection; 
import java.util.ArrayList;
import java.util.List;
import Daos.UsuarioDao; 


public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Parámetros de conexión
            String url = "jdbc:mysql://localhost:3309/postressaludables";
            String user = "root";
            String password = "";

        // Obtener la instancia de la conexión
            DatabaseConnection dbConnection = DatabaseConnection.getInstance(url, user, password) ;
            
        // Obtener un objeto usuario 
        //Usuario usuario = new Usuario (37, "Lucesita3", "3Lucecist2024@gmail.com", "Luce3"); 
        
   
         // obtener un objeto dao 
            Usu usuariodo = UsuarioF.ObUsu(dbConnection.getConnection()); // el metodo ObUsu de UsuarioF retorna un objeto dao
            
         // usuariodo.ingresoUsu(usuario) ;
         // usuariodo.mostrarunUsu(30); 
           
         // modificando el usuario con id 30    
         //   usuariodo.updateUsu(37, "Dalia", "Dalia2025@gmail.com", "Da09");
          //List<Usuario> usuarios= usuariodo.mostrarunUsu(37); 
          //for (Usuario usuario: usuarios){
            //  System.out.println(usuario);
          //}
       
        // borrando usuario determinado 
        //  usuariodo.deleteUsu(21);
        
          System.out.println(usuariodo.mostrarunUsu(3).getId() + " "+ usuariodo.mostrarunUsu(3).getNombre()+ " "+ usuariodo.mostrarunUsu(3).getEmail() +  " "+usuariodo.mostrarunUsu(3).getPassword());  
        
          //List<Usuario> usuarios = usuariodo.mostrarUsu(); 
        
    
        
        
    } 

    
}
