/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clasesproyecto;

/**
 *
 * @author Michael
 */

public class Preferencias {
    private String tipopostre; //helado, galletias, brownie
    private String nivelactividad;
    private int comidasaldia;
    private boolean prefiereOrganico; // Indica si prefiere alimentos orgánicos
    private boolean bajoEnAzucar;     // Indica si prefiere alimentos bajos en azucar
    private boolean altoEnProteinas;

    public Preferencias(String tipopostre, String nivelactividad, int comidasaldia, boolean prefiereOrganico, boolean bajoEnAzucar, boolean altoEnProteinas){
      this.tipopostre= tipopostre;
      this.nivelactividad=nivelactividad;
      this.comidasaldia=comidasaldia;
      this.prefiereOrganico=prefiereOrganico;
      this.bajoEnAzucar=bajoEnAzucar;
      this.altoEnProteinas=altoEnProteinas;
    }
    /**
     * @return the tipopostre
     */
    public String getTipopostre() {
        return tipopostre;
    }

    /**
     * @param tipopostre the tipopostre to set
     */
    public void setTipopostre(String tipopostre) {
        this.tipopostre = tipopostre;
    }

    /**
     * @return the nivelactividad
     */
    public String getNivelactividad() {
        return nivelactividad;
    }

    /**
     * @param nivelactividad the nivelactividad to set
     */
    public void setNivelactividad(String nivelactividad) {
        this.nivelactividad = nivelactividad;
    }

    /**
     * @return the comidasaldia
     */
    public int getComidasaldia() {
        return comidasaldia;
    }

    /**
     * @param comidasaldia the comidasaldia to set
     */
    public void setComidasaldia(int comidasaldia) {
        this.comidasaldia = comidasaldia;
    }

    /**
     * @return the prefiereOrganico
     */
    public boolean getPrefiereOrganico() {
        return prefiereOrganico;
    }

    /**
     * @param prefiereOrganico the prefiereOrganico to set
     */
    public void setPrefiereOrganico(boolean prefiereOrganico) {
        this.prefiereOrganico = prefiereOrganico;
    }

    /**
     * @return the bajoEnAzucar
     */
    public boolean getBajoEnAzucar() {
        return bajoEnAzucar;
    }

    /**
     * @param bajoEnAzucar the bajoEnAzucar to set
     */
    public void setBajoEnAzucar(boolean bajoEnAzucar) {
        this.bajoEnAzucar = bajoEnAzucar;
    }

    /**
     * @return the altoEnProteinas
     */
    public boolean getAltoEnProteinas() {
        return altoEnProteinas;
    }

    /**
     * @param altoEnProteinas the altoEnProteinas to set
     */
    public void setAltoEnProteinas(boolean altoEnProteinas) {
        this.altoEnProteinas = altoEnProteinas;
    }
}
