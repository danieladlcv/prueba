/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clasesproyecto;

import Interfacesmodelo.Notificacion;
import Clasesproyecto.NotificacionCorreo;
import Daos.NotificacionCorreoDao; 
/**
 *
 * @author Michael
 */
public class NotificacionF {
    
   // public static Notificacion crearNotificacion(String tipo, String usuario, String contraseña) {
    //    if (tipo.equalsIgnoreCase("correo")) {

          // return new NotificacionCorreoDao(usuario, contraseña);
           
    //    } else if (tipo.equalsIgnoreCase("sms")) {
            
           // return new NotificacionesSMS();
       // }
        
       // } throw new IllegalArgumentException("Tipo de notificación no soportado");
   //}   
}
