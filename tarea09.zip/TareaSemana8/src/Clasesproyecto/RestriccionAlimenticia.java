/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clasesproyecto;

/**
 *
 * @author Michael
 */
public class RestriccionAlimenticia {
    private int id;
    private String alergias;
    private boolean Gluten; 
    private boolean Lactosa; 
    private boolean Azucar; 
    private boolean Vegano; 
    private boolean Citrico; 
    private boolean Bajoengrasa; 
    
    public RestriccionAlimenticia(int id, String alergias, boolean Gluten, boolean Lactosa, boolean Azucar, boolean Vegano, boolean Citrico, boolean Bajoengrasa){
        this.id= id;
        this.alergias=alergias;
        this.Gluten= Gluten;
        this.Lactosa=Lactosa;
        this.Azucar= Azucar;
        this.Vegano= Vegano;
        this.Citrico= Citrico;
        this.Bajoengrasa= Bajoengrasa;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the alergias
     */
    public String getAlergias() {
        return alergias;
    }

    /**
     * @param alergias the alergias to set
     */
    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    /**
     * @return the Gluten
     */
    public boolean getGluten() {
        return Gluten;
    }

    /**
     * @param Gluten the Gluten to set
     */
    public void setGluten(boolean Gluten) {
        this.Gluten = Gluten;
    }

    /**
     * @return the Lactosa
     */
    public boolean getLactosa() {
        return Lactosa;
    }

    /**
     * @param Lactosa the Lactosa to set
     */
    public void setLactosa(boolean Lactosa) {
        this.Lactosa = Lactosa;
    }

    /**
     * @return the Azucar
     */
    public boolean getAzucar() {
        return Azucar;
    }

    /**
     * @param Azucar the Azucar to set
     */
    public void setAzucar(boolean Azucar) {
        this.Azucar = Azucar;
    }

    /**
     * @return the Vegano
     */
    public boolean getVegano() {
        return Vegano;
    }

    /**
     * @param Vegano the Vegano to set
     */
    public void setVegano(boolean Vegano) {
        this.Vegano = Vegano;
    }

    /**
     * @return the Citrico
     */
    public boolean getCitrico() {
        return Citrico;
    }

    /**
     * @param Citrico the Citrico to set
     */
    public void setCitrico(boolean Citrico) {
        this.Citrico = Citrico;
    }

    /**
     * @return the Bajoengrasa
     */
    public boolean getBajoengrasa() {
        return Bajoengrasa;
    }

    /**
     * @param Bajoengrasa the Bajoengrasa to set
     */
    public void setBajoengrasa(boolean Bajoengrasa) {
        this.Bajoengrasa = Bajoengrasa;
    }
}
