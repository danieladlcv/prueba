/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Daos;
import java.sql.Connection;

import Clasesproyecto.PlanAlimenticio;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Interfacesmodelo.PlanAlimenti;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Michael
 */
public class PlanAlimenticioDao implements PlanAlimenti{
    private Connection connection;
    
    public PlanAlimenticioDao(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<PlanAlimenticio> mostrarPlanAlimenticio(PlanAlimenticio planali) {
         try{
          List planAli = new ArrayList<>();
          String query = "CALL mostrarusuarios();";
          Statement stmt = (Statement) connection.createStatement();
          ResultSet rs = stmt.executeQuery(query);
          
          while (rs.next()) {
              int id = rs.getInt("id");
              String nombre = rs.getString("nombre");
              String email = rs.getString("email");
              String password= rs.getString("password");
              //planAli.add(new PlanAlimenticio(id, nombre, email,password));
          }
          return planAli;
      } catch (SQLException ex) {
          Logger.getLogger(PlanAlimenticioDao.class.getName()).log(Level.SEVERE, null, ex);
      }
      return null;
    }

    @Override
    public void updatePlanAlimenticio(PlanAlimenticio planali) {
      String sql = "{call sp_update_user(?, ?, ?)}"; // Procedimiento almacenado
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
           // stmt.setString(1, Integer.toString(planali.getId()));
           // stmt.setString(2, planali.getNombre());
           // stmt.setString(3, planali.getEmail());
           // stmt.setString(4, planali.getPassword());
            stmt.executeUpdate();
            connection.close();
        }catch (SQLException ex){
          Logger.getLogger(UsuarioDao.class.getName()).log(Level.SEVERE, null, ex); 
          
        }  
    }

    @Override
    public void ingresoPlanAlimenticio(PlanAlimenticio planali) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deletePlanAlimenticio(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
