/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interfacesmodelo;

import Clasesproyecto.PlanAlimenticio;
import java.util.List;

/**
 *
 * @author Michael
 */
public interface PlanAlimenti {
    List<PlanAlimenticio> mostrarPlanAlimenticio(PlanAlimenticio planali); 
    void updatePlanAlimenticio (PlanAlimenticio planali); 
    void ingresoPlanAlimenticio (PlanAlimenticio planali); 
    void deletePlanAlimenticio (int id); 
}
